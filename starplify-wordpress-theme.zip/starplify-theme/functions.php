<?php
if (!defined('ABSPATH')) exit;
function starplify_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('custom-logo');
  register_nav_menus(array('primary' => __('Primary Menu', 'starplify')));
}
add_action('after_setup_theme', 'starplify_setup');
function starplify_assets() {
  wp_enqueue_style('starplify-fonts', 'https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Inter:wght@400;500;600;700;800&display=swap', array(), null);
  wp_enqueue_style('starplify-main', get_stylesheet_uri(), array('starplify-fonts'), '1.0');
  wp_enqueue_style('starplify-css', get_template_directory_uri().'/assets/css/main.css', array('starplify-main'), '1.0');
  wp_enqueue_script('starplify-js', get_template_directory_uri().'/assets/js/main.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'starplify_assets');
function starplify_customize($wp_customize) {
  $wp_customize->add_section('starplify_home', array('title'=>'Starplify Homepage','priority'=>30));
  $fields = array(
    'hero_title'=>array('Hero heading','BECAUSE YOUR TALENT DESERVES THE SPOTLIGHT.'),
    'hero_text'=>array('Hero description','From auditions to final casting — streamline your entire journey with a platform designed for actors and recruiters.'),
    'actor_stat'=>array('Actor statistic','10,000+'),
    'roles_stat'=>array('Roles statistic','500+'),
    'casting_stat'=>array('Casting statistic','1,000+')
  );
  foreach ($fields as $key=>$item) {
    $wp_customize->add_setting('starplify_'.$key,array('default'=>$item[1],'sanitize_callback'=>'sanitize_text_field'));
    $wp_customize->add_control('starplify_'.$key,array('label'=>$item[0],'section'=>'starplify_home','type'=>'text'));
  }
}
add_action('customize_register','starplify_customize');
