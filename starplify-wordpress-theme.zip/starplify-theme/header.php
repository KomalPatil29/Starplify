<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<header class="site-header">
<a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="brand-symbol">✦</span><span>starplify<small>amplifying stardom</small></span></a>
<button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false"><span></span><span></span><span></span></button>
<nav class="main-nav"><a class="active" href="#home">HOME</a><a href="#about">ABOUT</a><a href="#talent">EXPLORE TALENT</a><a href="#how">HOW IT WORKS</a><a href="#stories">SUCCESS STORIES</a><a href="#casting">FOR CASTING DIRECTORS</a></nav>
<a class="profile" href="#join" aria-label="Profile">●</a>
</header>
