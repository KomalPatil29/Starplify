document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle'),nav=document.querySelector('.main-nav');
 if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',open?'true':'false')});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')))}
 const tabs=document.querySelectorAll('.tabs button'),quotes=document.querySelectorAll('.quotes article');
 tabs.forEach(tab=>tab.addEventListener('click',()=>{tabs.forEach(t=>t.classList.remove('active'));tab.classList.add('active');quotes.forEach((q,i)=>{q.querySelector('b').textContent=tab.dataset.kind==='recruiter'?['ROHAN MEHTA','PRIYA SINGH','KARAN SHAH','NEHA RAO','VIKRAM DAS','ANITA KAPOOR'][i]:['MEERA DAS','ANIL KUMAR','ARJUN PATIL','AISHA RAO','PRIYA SINGH','SITA VERMA'][i]);q.querySelector('small').textContent=tab.dataset.kind==='recruiter'?'Casting Director':['Drama','TV Advertisement','Music','Drama','TV Advertisement','Music'][i]})}));
});
