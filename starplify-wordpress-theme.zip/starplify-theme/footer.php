<footer class="site-footer"><div class="footer-grid">
<div class="footer-about"><a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="brand-symbol">✦</span><span>starplify<small>amplifying stardom</small></span></a><p>Don't miss out on the latest opportunities and updates. Follow us on social media, subscribe to our newsletter, and reach out anytime. We're here to help you succeed in your casting journey.</p><div class="social"><a href="#">f</a><a href="#">◎</a><a href="#">𝕏</a><a href="#">▶</a></div></div>
<div><h4>COMPANY</h4><a href="#about">ABOUT US</a><a href="#careers">CAREERS</a><a href="#legal">LEGAL PAGE</a></div>
<div><h4>FOR RESOURCES</h4><a href="#blog">BLOG</a><a href="#talent">TALENT SEARCH</a></div>
<div><h4>FOR APPLICANTS</h4><a href="#projects">SEARCH PROJECTS</a><a href="#faqs">FAQS</a></div>
</div><div class="footer-bottom"><span>© <?php echo esc_html(date('Y')); ?> Starplify</span><span><a href="#terms">TERMS & CONDITIONS</a>　|　<a href="#privacy">PRIVACY</a></span></div></footer>
<?php wp_footer(); ?></body></html>
